angular.module('appMaps', ['uiGmapgoogle-maps'])
    .controller('mainCtrl', function($scope,$rootScope, $timeout, $log,$q, $http) {
        $scope.location='';
        $scope.type='';
        $scope.listItems = [];
        $scope.imageName=[];
        $scope.cityMarkers=[];
        var results = this;
        $http.get("https://api.foursquare.com/v2/venues/search?" +
            "client_id=FHNVW0RNM0MK5WT1HEA1V2BHYFPIJNP2Y3HNV05BFVZDFZ0E&" +
            "client_secret=M1BDWESYNYZOETXW1OFWMVRVW4CPJV2IWIRWJE3FSUWHDZFQ&" +
            "v=20160906&ll=36.778261,-119.41793239999998&query=restaurants")
            .success(function(data){
                results = data;
                displayData(results);
            });
        $scope.map = {center: {latitude: 36.778261, longitude: -119.41793239999998}, zoom: 5 };
        $scope.options = {scrollwheel: false};
        $scope.coordsUpdates = 0;
        $scope.dynamicMoveCtr = 0;
        function getMarker(map){
            $scope.map.markersEvents = {
                mouseover: function (marker, eventName, model) {
                    model.showWindow = true;
                    $scope.$apply();
                },
                mouseout: function (marker, eventName, model) {

                    model.showWindow = false;
                    $scope.$apply();
                }
            };
            $scope.markers = [{
                id: 0,
                latitude: map.center.latitude,
                longitude: map.center.longitude,
                title: 'marker 1',
                showWindow: false,
                icon: './images/pin.png'
            }];
            $scope.$watchCollection("marker.coords", function (newVal, oldVal) {
                if (_.isEqual(newVal, oldVal))
                    return;
                $scope.coordsUpdates++;
            });
        }


        function displayData(result){
            var elements=result.response.venues;
            for(var i=0;i<elements.length;i++){
                var geocoder = new google.maps.Geocoder();
                $scope.listItems[i]=elements[i];
                var city=$scope.listItems[i].location.city+','+$scope.listItems[i].location.cc;

                $scope.infoData = $scope.listItems[i].location.city+$scope.listItems[i].location.address;
                geocoder.geocode( { 'address': city}, function(results, status) {
                    console.log('$scope.listItems[i]',google.maps.GeocoderStatus.OK);
                    if (status == google.maps.GeocoderStatus.OK) {
                       var latitude = results[0].geometry.location.lat();
                        var longitude = results[0].geometry.location.lng();
                        console.log(' $scope.cityMarkers',$scope.infoData,latitude,longitude);
                    }
                });
                
            }
console.log(' $scope.cityMarkers', $scope.cityMarkers);
        }
        $scope.searchClick = function () {
            var a= getLocation();
            a=a.split(',');
            var latitude= a[0];
            var longitude=a[1];
            var map = {center: {latitude: latitude, longitude: longitude }, zoom: 1 };
            getMarker(map);
        };

        var getLocation =  function() {
            var geocoder = new google.maps.Geocoder();
            var a='';
            geocoder.geocode( { 'address': $scope.location}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    $rootScope.latitude = results[0].geometry.location.lat();
                    $rootScope.longitude = results[0].geometry.location.lng();
                    a=$rootScope.latitude+''+$rootScope.longitude;
                    console.log(a);
                    var results = this;
                    $http.get("https://api.foursquare.com/v2/venues/search?" +
                        "client_id=FHNVW0RNM0MK5WT1HEA1V2BHYFPIJNP2Y3HNV05BFVZDFZ0E&" +
                        "client_secret=M1BDWESYNYZOETXW1OFWMVRVW4CPJV2IWIRWJE3FSUWHDZFQ&" +
                        "v=20160906&ll="+$rootScope.latitude+","+$rootScope.longitude+"&query="+$scope.type+"")
                        .success(function(data){
                            results = data;
                           displayData(results);
                        });
                }
            });
            return $rootScope.latitude+','+$rootScope.longitude ;
        }

        getMarker($scope.map);
        
    });